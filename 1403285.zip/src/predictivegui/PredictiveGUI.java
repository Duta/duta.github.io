package predictivegui;

import predictive.Dictionary;
import predictive.DictionaryTreeImpl;
import java.awt.BorderLayout;
import javax.swing.JFrame;

/**
 * A window containing a TextView and a ButtonsController.
 * Resembles a phone sending an SMS.
 */
public class PredictiveGUI extends JFrame {
    /**
     * Creates the PredictiveGUI.
     * Contains a TextView and a ButtonsController.
     *
     * @param dict the dictionary to use
     */
    public PredictiveGUI(Dictionary dict) {
        // Set the title and layout
        setTitle("iPhone 4S");
        setLayout(new BorderLayout());

        // Create the TextView and ButtonsController
        PredictiveModel model = new PredictiveModel(dict);
        add(new TextView(model), BorderLayout.CENTER);
        add(new ButtonsController(model), BorderLayout.SOUTH);

        // Boilerplate JFrame stuff:

        // Ensure the frame closes correctly
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Layout the elements
        pack();

        // Don't allow the user to make the
        // frame any smaller than it is
        setMinimumSize(getSize());

        // Center the frame
        setLocationRelativeTo(null);
    }

    /**
     * The program's entry point.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("Loading");
        new PredictiveGUI(new DictionaryTreeImpl()).setVisible(true);
    }
}
