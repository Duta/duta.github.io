package predictivegui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
public class ButtonAction extends AbstractAction {
    private ActionListener listener;

    /**
     * Creates a 'blank' ButtonAction, with
     * no text and no on-click events.
     */
    public ButtonAction() {
        this("", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {}
        });
    }

    /**
     * Creates a ButtonAction with the
     * given text and ActionListener.
     *
     * @param text the button's text
     * @param listener the on-click ActionListener
     */
    public ButtonAction(String text, ActionListener listener) {
        super(text);
        this.listener = listener;
    }

    /**
     * Called when the button is clicked.
     * Logs the button press, and delegates
     * the call to the ButtonAction's listener.
     *
     * @param e the event associated with the action
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Button " + getValue(NAME) + " clicked");
        listener.actionPerformed(e);
    }
}
