package predictivegui;

import predictive.Dictionary;

import java.util.*;

/**
 * Represents a list of words typed into
 * a phone's SMS creation window.
 */
public class PredictiveModel extends Observable {
    private Dictionary dictionary;
    private List<String> words;

    /**
     * Creates a PredictiveModel which
     * uses the given Dictionary.
     *
     * @param dictionary the dictionary to use
     */
    public PredictiveModel(Dictionary dictionary) {
        this.dictionary = dictionary;
        this.words = new ArrayList<String>();
        this.words.add("");
    }

    /**
     * Converts a numeric signature to words.
     *
     * @param signature the numeric signature to convert
     * @return the words with the given signature
     */
    public Set<String> signatureToWords(String signature) {
        return dictionary.signatureToWords(signature);
    }

    /**
     * Returns the list of words this model is storing.
     * You should not modify this list directly.
     *
     * @return the list of words this model is storing
     */
    public List<String> getWords() {
        return words;
    }

    /**
     * Adds the given word to the end of the words list.
     * @param word the word to add
     */
    public void addWord(String word) {
        System.out.println("Word added: " + word);
        words.add(word);
        setChanged();
        notifyObservers();
    }

    /**
     * Replaces the last word in the list.
     * If the list of words is empty, does nothing.
     *
     * @param word the new word to replace with
     */
    public void replaceLast(String word) {
        if(!words.isEmpty()) {
            int lastIndex = words.size() - 1;
            System.out.println("Replaced " + words.get(lastIndex) + " with " + word);
            words.remove(lastIndex);
            words.add(word);
            setChanged();
            notifyObservers();
        }
    }
}
