package predictivegui;

import java.awt.BorderLayout;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Represents a phone's SMS creation view.
 */
public class TextView extends JPanel implements Observer {
    private PredictiveModel model;
    private JTextArea textArea;

    /**
     * Creates a TextView backed by the given model.
     *
     * @param model the model backing the view
     */
    public TextView(PredictiveModel model) {
        this.model = model;
        this.textArea = new JTextArea();

        model.addObserver(this);

        textArea.setEditable(false);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);

        setLayout(new BorderLayout());
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        refresh();
    }

    /**
     * This method is called when the model changes.
     *
     * @param obs the model that changed
     * @param obj an argument passed to notifyObservers
     */
    @Override
    public void update(Observable obs, Object obj) {
        refresh();
    }

    /**
     * Refreshes the TextView to reflect
     * the current state of the model.
     */
    private void refresh() {
        // If only we could use Java8's String.join()
        System.out.println("Refreshing TextView");
        List<String> words = model.getWords();
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < words.size(); i++) {
            if(i != 0) {
                sb.append(' ');
            }
            sb.append(words.get(i));
        }
        textArea.setText(sb.toString());
    }
}
