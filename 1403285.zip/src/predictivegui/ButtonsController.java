package predictivegui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * A 3x4 grid of buttons, which resemble a phone's keypad.
 * These buttons can be used to manipulate the given model.
 */
public class ButtonsController extends JPanel {
    private PredictiveModel model;
    private String signature;
    private List<String> words;
    private int wordIndex;

    /**
     * Creates a ButtonsController controlling the given model.
     * @param model the model to control
     */
    public ButtonsController(PredictiveModel model) {
        // Initialize the fields
        this.model = model;
        this.signature = "";
        this.words = new ArrayList<String>();
        this.wordIndex = 0;

        // Set the layout
        int numRows = 4;
        int numCols = 3;
        int hGap = 2;
        int vGap = 2;
        setLayout(new GridLayout(numRows, numCols, hGap, vGap));

        // Add the buttons
        for(int row = 0; row < numRows; row++) {
            for(int col = 0; col < numCols; col++) {
                add(createButton(col + row*numCols));
            }
        }
    }

    /**
     * Returns the current word.
     * If there are no words, returns the empty string.
     *
     * @return the current word
     */
    private String getWord() {
        return words.isEmpty() ? "" : words.get(wordIndex);
    }

    /**
     * Creates the i'th button and returns it.
     *
     * @param i the index of the button to create
     * @return the i'th button
     */
    private JButton createButton(int i) {
        // Get the correct button action and create
        // a button based on the action.
        JButton button = new JButton(createButtonAction(i));
        // Give it some default styling
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        return button;
    }

    /**
     * Creates the i'th ButtonAction and returns it.
     * @param i the index of the ButtonAction to create
     * @return the i'th ButtonAction
     */
    private ButtonAction createButtonAction(int i) {
        if(i < 9) {
            // The first 9 buttons are the keys 1-9

            // Get the button's text
            final String num = "" + (i + 1);
            // If it corresponds to any letters,
            // append those to the button's text.
            String keys = new String(keyToLetter(num.charAt(0)));
            String text = keys.isEmpty() ? num : num + " " + keys;
            return new ButtonAction(text, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Store the initial signature in
                    // case we need to revert
                    String oldSignature = signature;
                    // Append the number to the signature
                    // and get the new set of words
                    signature += num;
                    Set<String> wordsSet = model.signatureToWords(signature);
                    if(wordsSet.isEmpty()) {
                        // If no words exist for that
                        // signature, undo the button press
                        signature = oldSignature;
                    } else {
                        // Update the model
                        words = new ArrayList<String>(wordsSet);
                        wordIndex = 0;
                        model.replaceLast(getWord());
                    }
                }
            });
        } else {
            switch(i) {
            case 9:
                return new ButtonAction("*", new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(!words.isEmpty()) {
                            // If words exist for this signature, move to the next one
                            wordIndex++;
                            wordIndex %= words.size();
                            model.replaceLast(getWord());
                        }
                    }
                });
            case 10:
                return new ButtonAction("0", new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Reset the fields, and move to the next word
                        signature = "";
                        words = new ArrayList<String>();
                        wordIndex = 0;
                        model.addWord("");
                    }
                });
            case 11:
                return new ButtonAction("#", new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(!signature.isEmpty()) {
                            // If there are characters in the signature,
                            // remove the last one (and then update the model)
                            signature = signature.substring(0, signature.length() - 1);
                            words = new ArrayList<String>(model.signatureToWords(signature));
                            wordIndex = 0;
                            model.replaceLast(getWord());
                        }
                    }
                });
            default:
                // Return a default button action if we're asked
                // to create more buttons than expected.
                // This means instead of crashing the program,
                // we just have some placeholder buttons.
                // This can also be useful to check the layout
                // is correct before adding functionality.
                return new ButtonAction();
            }
        }
    }

    /**
     * Given a key on the phone, returns the set of
     * letters that the key corresponds to.
     *
     * @param key the key to get letters for
     * @return the corresponding letters
     */
    private char[] keyToLetter(char key) {
        switch(key) {
        case '2': return new char[] { 'a', 'b', 'c' };
        case '3': return new char[] { 'd', 'e', 'f' };
        case '4': return new char[] { 'g', 'h', 'i' };
        case '5': return new char[] { 'j', 'k', 'l' };
        case '6': return new char[] { 'm', 'n', 'o' };
        case '7': return new char[] { 'p', 'q', 'r', 's' };
        case '8': return new char[] { 't', 'u', 'v' };
        case '9': return new char[] { 'w', 'x', 'y', 'z' };
        default:  return new char[0];
        }
    }
}

