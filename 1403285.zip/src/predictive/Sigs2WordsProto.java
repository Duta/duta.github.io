package predictive;

public class Sigs2WordsProto {
    public static void main(String[] args) {
        for(String arg : args) {
            System.out.print(arg + " :");
            for(String word : PredictivePrototype.signatureToWords(arg)) {
                System.out.print(" " + word);
            }
            System.out.println();
        }
    }
}
