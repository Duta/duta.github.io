package predictive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
public class PredictivePrototype {
    /**
     * Converts a word to a numeric signature.
     * For example, "home" will return "4663".
     * Any non-alpha letters will appear as a
     * space (' ') character in the signature.
     *
     * @param word the word to convert
     * @return the numeric signature of the word
     */
    public static String wordToSignature(String word) {
        // Use StringBuffer as we'll be appending in
        // a loop. If we do not do this, and were
        // for example to do 'str += "something"'
        // a new StringBuilder object would have
        // to be created on each iteration of
        // the loop (since that is what the java
        // compiler converts string concatenation
        // to). This is a large overhead and slows
        // down the operation tremendously.
        // We use StringBuffer instead of
        // StringBuilder for thread safety.
        StringBuffer buffer = new StringBuffer();
        // Lowercase the word and iterate over it
        for(char letter : word.toLowerCase().toCharArray()) {
            // Convert it to a key and append
            // that to the signature buffer
            buffer.append(letterToKey(letter));
        }
        return buffer.toString();
    }

    /**
     * Converts a numeric signature to words.
     * Reads words from 'usr/share/dict/words'
     * and each word that matches the given
     * numeric signature will be included.
     * Each word in the returned set will be
     * lowercase.
     *
     * @param signature the numeric signature to convert
     * @return the words with the given signature
     */
    public static Set<String> signatureToWords(String signature) {
        // The set of words we will return
        Set<String> words = new HashSet<String>();
        // The dictionary file we will use
        String file = "/usr/share/dict/words";
        // The dictionary reader
        BufferedReader dictReader;
        try {
            // Try to create it
            dictReader = new BufferedReader(new FileReader(file));
        } catch(IOException ex) {
            // If something went wrong (for
            // example we couldn't find the
            // file), say so and return
            // the empty set we created
            System.err.println("Couldn't open dictionary file.");
            return words;
        }
        try {
            String line;
            // Read the file line by line, until
            // we reach the end of the file
            while((line = dictReader.readLine()) != null) {
                // Lowercase the line
                line = line.toLowerCase();
                // If it matches the signature
                if(wordToSignature(line).equals(signature)) {
                    // Add it to the set of words
                    words.add(line);
                }
                // NOTE: We ignore lines with non-alpha
                // characters implicitly, since non-alpha
                // characters will be converted to ' '
                // rather than a digit character, and
                // hence won't match the signature.
            }
            // NOTE: This implementation is inefficient
            // in that it has linear time complexity.
            // The reason for this is because to implement
            // something like binary search rather than
            // the linear search we have here, we'd need
            // to have the dictionary in memory.
            // We could implement binary search without
            // the dictionary in memory if the words were
            // a fixed length (using RandomAccessFile),
            // but sadly that is not the case.
        } catch(IOException ex) {
            // If an error occured in the
            // reading of the file, say
            // so and return the set we
            // created. If the error
            // occurred partway through
            // the reading of the file,
            // we'll have included all
            // the words we saw prior
            // to the error occurring
            System.err.println("Couldn't read from dictionary file.");
            return words;
        }
        try {
            // Try to close the file reader
            dictReader.close();
        } catch(IOException ex) {
            // If it fails, say so.
            System.err.println("Couldn't close dictionary file.");
        }
        return words;
    }

    public static char letterToKey(char letter) {
        switch(letter) {
        case 'a': case 'b': case 'c':           return '2';
        case 'd': case 'e': case 'f':           return '3';
        case 'g': case 'h': case 'i':           return '4';
        case 'j': case 'k': case 'l':           return '5';
        case 'm': case 'n': case 'o':           return '6';
        case 'p': case 'q': case 'r': case 's': return '7';
        case 't': case 'u': case 'v':           return '8';
        case 'w': case 'x': case 'y': case 'z': return '9';
        default:                                return ' ';
        }
    }

    public static char[] keyToLetter(char key) {
        switch(key) {
        case '2': return new char[] { 'a', 'b', 'c' };
        case '3': return new char[] { 'd', 'e', 'f' };
        case '4': return new char[] { 'g', 'h', 'i' };
        case '5': return new char[] { 'j', 'k', 'l' };
        case '6': return new char[] { 'm', 'n', 'o' };
        case '7': return new char[] { 'p', 'q', 'r', 's' };
        case '8': return new char[] { 't', 'u', 'v' };
        case '9': return new char[] { 'w', 'x', 'y', 'z' };
        default:  return new char[0];
        }
    }
}
