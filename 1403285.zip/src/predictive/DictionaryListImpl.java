package predictive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class DictionaryListImpl implements Dictionary {
    private List<WordSig> dictionary;

    /**
     * Creates a new DictionaryListImpl.
     * Initially loads the dictionary with
     * words from '/usr/share/dict/words'
     */
    public DictionaryListImpl() {
        dictionary = new ArrayList<WordSig>();
        updateDictionary("/usr/share/dict/words");
    }

    /**
     * Updates the dictionary of words.
     *
     * @param file the dictionary file's name
     */
    @Override
    public void updateDictionary(String file) {
        // Clear the dictionary
        dictionary.clear();
        // The dictionary reader
        BufferedReader dictReader;
        try {
            // Try to create it
            dictReader = new BufferedReader(new FileReader(file));
        } catch(IOException ex) {
            // If something went wrong (for example we
            // couldn't find the file), say so and return
            System.err.println("Couldn't open dictionary file.");
            return;
        }
        try {
            String line;
            // Read the file line by line, until
            // we reach the end of the file
            while((line = dictReader.readLine()) != null) {
                // Lowercase the line
                String word = line.toLowerCase();
                // Ensure that it's valid
                if(!isValidWord(word)) {
                    continue;
                }
                // Get its signature
                String signature = wordToSignature(word);
                // Add the word/signature pair to the dictionary
                dictionary.add(new WordSig(word, signature));
            }
        } catch(IOException ex) {
            // If an error occured in the reading of the file,
            // say so. If the error occurred partway through
            // the reading of the file, we'll have included
            // all the words we saw prior to the error occurring
            System.err.println("Couldn't read from dictionary file.");
        }
        try {
            // Try to close the file reader
            dictReader.close();
        } catch(IOException ex) {
            // If it fails, say so.
            System.err.println("Couldn't close dictionary file.");
        }
        // Ensure the dictionary is sorted
        Collections.sort(dictionary);
    }

    /**
     * Converts a word to a numeric signature.
     * For example, "home" will return "4663".
     * Any non-alpha letters will appear as a
     * space (' ') character in the signature.
     *
     * @param word the word to convert
     * @return the numeric signature of the word
     */
    @Override
    public String wordToSignature(String word) {
        StringBuffer buffer = new StringBuffer();
        // Lowercase the word and iterate over it
        for(char letter : word.toLowerCase().toCharArray()) {
            // Convert it to a key and append
            // that to the signature buffer
            buffer.append(letterToKey(letter));
        }
        return buffer.toString();
    }

    /**
     * Converts a numeric signature to words.
     * Checks the signature against each word
     * in the dictionary file, and each
     * word whose signature matches will be
     * included in the returned set.
     * Each word in the returned set will be
     * lowercase.
     *
     * @param signature the numeric signature to convert
     * @return the words with the given signature
     */
    @Override
    public Set<String> signatureToWords(String signature) {
        // The set of words we will return
        Set<String> words = new HashSet<String>();
        // Search the dictionary for a matching word
        WordSig key = new WordSig("", signature);
        int index = Collections.binarySearch(dictionary, key);
        // If it wasn't found, return the empty set of words
        if(index < 0) {
            return words;
        }
        // Loop left and right through the dictionary,
        // looking for matching words. We can do this
        // since the dictionary is sorted by signature.
        for(int i = index; matchesKey(i, key) && i >= 0; i--) {
            words.add(dictionary.get(i).getWord());
        }
        int len = dictionary.size();
        for(int i = index + 1; matchesKey(i, key) && i < len; i++) {
            words.add(dictionary.get(i).getWord());
        }
        // Return the set of words
        return words;
    }

    private boolean matchesKey(int wordIndex, WordSig key) {
        return dictionary.get(wordIndex).getSignature().equals(key.getSignature());
    }

    private static char letterToKey(char letter) {
        switch(letter) {
        case 'a': case 'b': case 'c':           return '2';
        case 'd': case 'e': case 'f':           return '3';
        case 'g': case 'h': case 'i':           return '4';
        case 'j': case 'k': case 'l':           return '5';
        case 'm': case 'n': case 'o':           return '6';
        case 'p': case 'q': case 'r': case 's': return '7';
        case 't': case 'u': case 'v':           return '8';
        case 'w': case 'x': case 'y': case 'z': return '9';
        default:                                return ' ';
        }
    }

    private boolean isValidWord(String word) {
        // For each character in the word
        for(char ch : word.toCharArray()) {
            // Ensure it is a lowercase letter
            if(ch < 'a' || ch > 'z') {
                return false;
            }
        }
        return true;
    }
}
