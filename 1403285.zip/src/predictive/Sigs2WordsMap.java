package predictive;

public class Sigs2WordsMap {
    public static void main(String[] args) {
        /*
         * 22 signature input
         * ------------------
         * List: 6.4s
         * Map: 5.5s
         * Tree: 10.0s
         */
        Dictionary conv = new DictionaryMapImpl();
        for(String arg : args) {
            System.out.print(arg + " :");
            for(String word : conv.signatureToWords(arg)) {
                System.out.print(" " + word);
            }
            System.out.println();
        }
    }
}
