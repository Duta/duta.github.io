package predictive;

public class Words2SigProto {
    public static void main(String[] args) {
        for(String arg : args) {
            String sig = PredictivePrototype.wordToSignature(arg);
            System.out.println(arg + ": " + sig);
        }
    }
}

