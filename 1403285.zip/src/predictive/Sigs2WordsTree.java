package predictive;

public class Sigs2WordsTree {
    public static void main(String[] args) {
        Dictionary conv = new DictionaryTreeImpl();
        for(String arg : args) {
            System.out.print(arg + " :");
            for(String word : conv.signatureToWords(arg)) {
                System.out.print(" " + word);
            }
            System.out.println();
        }
    }
}
