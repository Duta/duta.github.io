package predictive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public interface Dictionary {
    /**
     * Updates the dictionary of words.
     *
     * @param file the dictionary file's name
     */
    public void updateDictionary(String file);

    /**
     * Converts a word to a numeric signature.
     * For example, "home" will return "4663".
     * Any non-alpha letters will appear as a
     * space (' ') character in the signature.
     *
     * @param word the word to convert
     * @return the numeric signature of the word
     */
    public String wordToSignature(String word);

    /**
     * Converts a numeric signature to words.
     * Checks the signature against each word
     * in 'usr/share/dict/words', and each
     * word whose signature matches will be
     * included in the returned set.
     * Each word in the returned set will be
     * lowercase.
     *
     * @param signature the numeric signature to convert
     * @return the words with the given signature
     */
    public Set<String> signatureToWords(String signature);
}
