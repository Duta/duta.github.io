package predictive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
public class DictionaryTreeImpl implements Dictionary {
    private int length;
    private Set<String> words;
    private DictionaryTreeImpl[] children;

    /**
     * Creates a new DictionaryTreeImpl.
     * Initially loads the dictionary with
     * words from '/usr/share/dict/words'
     */
    public DictionaryTreeImpl() {
        this("/usr/share/dict/words");
    }

    /**
     * Creates a new DictionaryTreeImpl.
     * Initially loads the dictionary with
     * words from the given file
     *
     * @param file the dictionary file's name
     */
    public DictionaryTreeImpl(String file) {
        this(0);
        updateDictionary(file);
    }

    private DictionaryTreeImpl(int length) {
        this.length = length;
        this.words = new HashSet<String>();
        this.children = new DictionaryTreeImpl[8];
    }

    /**
     * Updates the dictionary of words.
     *
     * @param file the dictionary file's name
     */
    @Override
    public void updateDictionary(String file) {
        // Clear the dictionary
        words.clear();
        for(int i = 0; i < children.length; i++) {
            children[i] = null;
        }
        // The dictionary reader
        BufferedReader dictReader;
        try {
            // Try to create it
            dictReader = new BufferedReader(new FileReader(file));
        } catch(IOException ex) {
            // If something went wrong (for example we
            // couldn't find the file), say so and return
            System.err.println("Couldn't open dictionary file.");
            return;
        }
        try {
            String line;
            // Read the file line by line, until
            // we reach the end of the file
            while((line = dictReader.readLine()) != null) {
                // Lowercase the line
                String word = line.toLowerCase();
                // Ensure that it's valid
                if(!isValidWord(word)) {
                    continue;
                }
                // Add the signature/word mapping
                add(word);
            }
        } catch(IOException ex) {
            // If an error occured in the reading of the file,
            // say so. If the error occurred partway through
            // the reading of the file, we'll have included
            // all the words we saw prior to the error occurring
            System.err.println("Couldn't read from dictionary file.");
        }
        try {
            // Try to close the file reader
            dictReader.close();
        } catch(IOException ex) {
            // If it fails, say so.
            System.err.println("Couldn't close dictionary file.");
        }
    }

    /**
     * Converts a word to a numeric signature.
     * For example, "home" will return "4663".
     * Any non-alpha letters will appear as a
     * space (' ') character in the signature.
     *
     * @param word the word to convert
     * @return the numeric signature of the word
     */
    @Override
    public String wordToSignature(String word) {
        StringBuffer buffer = new StringBuffer();
        // Lowercase the word and iterate over it
        for(char letter : word.toLowerCase().toCharArray()) {
            // Convert it to a key and append
            // that to the signature buffer
            buffer.append(letterToKey(letter));
        }
        return buffer.toString();
    }

    /**
     * Converts a numeric signature to words.
     * Checks the signature against each word
     * in the dictionary file, and each
     * word whose signature matches will be
     * included in the returned set.
     * Also, any words whose signatures are
     * prefixed by the given signature will
     * be included (trimmed to the length
     * of the given signature).
     * Each word in the returned set will be
     * lowercase.
     *
     * @param signature the numeric signature to convert
     * @return the words with the given signature
     */
    @Override
    public Set<String> signatureToWords(String signature) {
        for(char ch : signature.toCharArray()) {
            if(ch < '2' || ch > '9') {
                return new HashSet<String>();
            }
        }
        if(signature.isEmpty()) {
            return new HashSet<String>();
        }
        return getChild(signature).getWords(true);
    }

    private Set<String> getWords(boolean trim) {
        Set<String> allWords = new HashSet<String>(words);
        for(DictionaryTreeImpl child : children) {
            if(child == null) {
                continue;
            }
            Set<String> childWords = child.getWords(false);
            if(trim) {
                for(String word : childWords) {
                    allWords.add(word.substring(0, length));
                }
            } else {
                allWords.addAll(childWords);
            }
        }
        return allWords;
    }

    private DictionaryTreeImpl getChild(String signature) {
        DictionaryTreeImpl node = this;
        for(char num : signature.toCharArray()) {
            node = node.getChild(num);
        }
        return node;
    }

    private DictionaryTreeImpl getChild(char num) {
        int index = num - '2';
        if(children[index] == null) {
            children[index] = new DictionaryTreeImpl(length + 1);
        }
        return children[index];
    }

    private void add(String word) {
        String signature = wordToSignature(word);
        DictionaryTreeImpl node = getChild(signature);
        node.words.add(word);
    }

    private static char letterToKey(char letter) {
        switch(letter) {
        case 'a': case 'b': case 'c':           return '2';
        case 'd': case 'e': case 'f':           return '3';
        case 'g': case 'h': case 'i':           return '4';
        case 'j': case 'k': case 'l':           return '5';
        case 'm': case 'n': case 'o':           return '6';
        case 'p': case 'q': case 'r': case 's': return '7';
        case 't': case 'u': case 'v':           return '8';
        case 'w': case 'x': case 'y': case 'z': return '9';
        default:                                return ' ';
        }
    }

    private boolean isValidWord(String word) {
        // For each character in the word
        for(char ch : word.toCharArray()) {
            // Ensure it is a lowercase letter
            if(ch < 'a' || ch > 'z') {
                return false;
            }
        }
        return true;
    }
}
