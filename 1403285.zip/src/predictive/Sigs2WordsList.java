package predictive;

public class Sigs2WordsList {
    public static void main(String[] args) {
        /*
         * Small input (43556):
         * Proto: 1334
         * List: 4383
         * Big input (43556, 626, 523, 68773, 2287, 228, 364, 5664, 74678)
         * Proto: 6783
         * List: 4257
         */
        Dictionary conv = new DictionaryListImpl();
        for(String arg : args) {
            System.out.print(arg + " :");
            for(String word : conv.signatureToWords(arg)) {
                System.out.print(" " + word);
            }
            System.out.println();
        }
    }
}
