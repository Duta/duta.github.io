package predictive;

import java.util.ArrayList;
import java.util.List;
public class WordSig implements Comparable<WordSig> {
    private String word;
    private String signature;
    
    public WordSig(String word, String signature) {
        this.word = word;
        this.signature = signature;
    }

    public String getWord() {
        return word;
    }

    public String getSignature() {
        return signature;
    }

    @Override
    public int compareTo(WordSig that) {
        int lengthDiff = this.signature.length() - that.signature.length();
        if(lengthDiff != 0) {
            return lengthDiff;
        }
        char[] thisSignature = this.signature.toCharArray();
        char[] thatSignature = that.signature.toCharArray();
        int length = thisSignature.length;
        for(int i = 0; i < length; i++) {
            int charDiff = thisSignature[i] - thatSignature[i];
            if(charDiff != 0) {
                return charDiff;
            }
        }
        return 0;
    }

    @Override
    public String toString() {
        return "{'" + word + "', " + signature + "}";
    }
}
