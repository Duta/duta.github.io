package predictive;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import static org.testng.Assert.assertEquals;

@Test
public class DictionaryMapImplTest {
    private Dictionary testDictionary;

    @BeforeClass
    public void setUp() {
        testDictionary = new DictionaryMapImpl();
    }

    @DataProvider(name = "wordSignaturePairsProvider")
    public Object[][] wordSignaturePairsProvider() {
        return new Object[][] {
                { "hello"      , "43556"      },
                { "Test"       , "8378"       },
                { "CAT"        , "228"        },
                { ""           , ""           },
                { "agjriehga"  , "245743442"  },
                { "54326"      , "     "      },
                { "john@smith" , "5646 76484" }
        };
    }

    @Test(dataProvider = "wordSignaturePairsProvider")
    public void wordToSignatureTest(String word, String signature) {
        assertEquals(testDictionary.wordToSignature(word), signature);
    }

    @DataProvider(name = "signatureWordsPairsProvider")
    public Object[][] signatureWordsPairsProvider() {
        return new Object[][] {
                { "43556",        Arrays.asList("hello", "gekko") },
                { "3",            Arrays.asList("f", "d", "e") },
                { "7463",         Arrays.asList("rhne", "pind", "sind", "sine",
                                                "sime", "simd", "shod", "pine",
                                                "shoe", "rime", "rind", "rine") },
                { "643274578546", Arrays.asList() },
                { "",             Arrays.asList() },
                { "01010101",     Arrays.asList() },
                { "hello",        Arrays.asList() },
        };
    }

    @Test(dataProvider = "signatureWordsPairsProvider")
    public void signatureToWordsTest(String signature, List<String> words) {
        assertEquals(testDictionary.signatureToWords(signature), new HashSet<String>(words));
    }
}
